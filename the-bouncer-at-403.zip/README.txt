A Pen created at CodePen.io. You can find this one at https://codepen.io/doowybbob/pen/gdZgpe.

 A 403 Forbidden page in pure CSS!

Elements inspired by: https://dribbble.com/shots/3901100-Invite